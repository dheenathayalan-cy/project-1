"""
network_isolation.py — Automated network isolation / restoration.

Supports three modes controlled by config.ISOLATION_MODE:
  "simulate" — log only, no real changes  (safe for demos / testing)
  "enforce"  — apply real firewall rules  (requires admin / root)

Platform-specific commands
──────────────────────────
Windows : netsh advfirewall commands
Linux   : iptables / ufw
macOS   : pfctl (pf firewall)
"""

import sys
import logging
import subprocess
import platform
from datetime import datetime

from config import ISOLATION_MODE

logger = logging.getLogger("RansomwareDetector")

_isolated = False          # module-level state


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC API
# ══════════════════════════════════════════════════════════════════════════════

def isolate_network():
    """Block all inbound and outbound network traffic."""
    global _isolated
    if _isolated:
        logger.info("Network already isolated — skipping duplicate call.")
        return

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logger.critical(f"[{ts}] 🌐 NETWORK ISOLATION INITIATED")

    if ISOLATION_MODE == "simulate":
        _simulate("BLOCK ALL TRAFFIC")
        _isolated = True
        return

    ok = _platform_isolate()
    if ok:
        _isolated = True
        logger.critical("✅ Network successfully isolated.")
    else:
        logger.error("❌ Network isolation failed — check privileges.")


def restore_network():
    """Remove the blocking rules and restore connectivity."""
    global _isolated
    if not _isolated:
        logger.info("Network is not isolated — nothing to restore.")
        return

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logger.info(f"[{ts}] 🌐 NETWORK RESTORATION INITIATED")

    if ISOLATION_MODE == "simulate":
        _simulate("RESTORE ALL TRAFFIC")
        _isolated = False
        return

    ok = _platform_restore()
    if ok:
        _isolated = False
        logger.info("✅ Network connectivity restored.")
    else:
        logger.error("❌ Network restoration failed — check privileges.")


def is_isolated() -> bool:
    return _isolated


# ══════════════════════════════════════════════════════════════════════════════
# INTERNALS
# ══════════════════════════════════════════════════════════════════════════════

def _simulate(action: str):
    logger.warning(f"[SIMULATE] Network action: {action} (no real changes made)")
    logger.warning("[SIMULATE] In 'enforce' mode this would apply firewall rules.")


def _run(cmd: list[str]) -> bool:
    """Run a shell command. Return True on success."""
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return True
        logger.error(f"Command failed: {' '.join(cmd)}\n{result.stderr.strip()}")
        return False
    except FileNotFoundError:
        logger.error(f"Command not found: {cmd[0]}")
        return False
    except subprocess.TimeoutExpired:
        logger.error(f"Command timed out: {' '.join(cmd)}")
        return False


def _platform_isolate() -> bool:
    os_name = platform.system()

    if os_name == "Windows":
        return all([
            _run(["netsh", "advfirewall", "set", "allprofiles",
                  "firewallpolicy", "blockinbound,blockoutbound"]),
        ])

    if os_name == "Linux":
        # Try iptables first, then ufw
        if _run(["which", "iptables"]):
            return all([
                _run(["iptables", "-P", "INPUT",   "DROP"]),
                _run(["iptables", "-P", "OUTPUT",  "DROP"]),
                _run(["iptables", "-P", "FORWARD", "DROP"]),
            ])
        if _run(["which", "ufw"]):
            return _run(["ufw", "--force", "reset"]) and _run(["ufw", "default", "deny"])

    if os_name == "Darwin":
        # macOS: load a pf ruleset that blocks everything
        rules = b"block all\n"
        try:
            proc = subprocess.run(
                ["pfctl", "-ef", "-"],
                input=rules, capture_output=True, timeout=10
            )
            return proc.returncode == 0
        except Exception as e:
            logger.error(f"pfctl error: {e}")
            return False

    logger.error(f"Unsupported OS: {os_name}")
    return False


def _platform_restore() -> bool:
    os_name = platform.system()

    if os_name == "Windows":
        return _run(["netsh", "advfirewall", "set", "allprofiles",
                     "firewallpolicy", "blockinbound,allowoutbound"])

    if os_name == "Linux":
        if _run(["which", "iptables"]):
            return all([
                _run(["iptables", "-P", "INPUT",   "ACCEPT"]),
                _run(["iptables", "-P", "OUTPUT",  "ACCEPT"]),
                _run(["iptables", "-P", "FORWARD", "ACCEPT"]),
            ])
        if _run(["which", "ufw"]):
            return _run(["ufw", "default", "allow"])

    if os_name == "Darwin":
        try:
            proc = subprocess.run(["pfctl", "-d"], capture_output=True, timeout=10)
            return proc.returncode == 0
        except Exception as e:
            logger.error(f"pfctl error: {e}")
            return False

    logger.error(f"Unsupported OS: {os_name}")
    return False
