"""
alerts.py — Alert dispatcher.

Sends alerts via:
  1. Coloured console print
  2. System beep (optional, config.ALERT_SOUND)
  3. Desktop notification (optional — uses plyer if installed)
  4. Log file (handled by the central logger)
"""

import sys
import logging
from datetime import datetime

from config import ALERT_SOUND

logger = logging.getLogger("RansomwareDetector")

# ─── severity → colour ───────────────────────────────────────────────────────
RESET  = "\033[0m"
RED    = "\033[91m"
YELLOW = "\033[93m"
BOLD   = "\033[1m"


def send_alert(message: str, score: int = 0):
    """
    Dispatch an alert with the given *message* and threat *score*.
    score < 10  → warning
    score >= 10 → critical
    """
    ts = datetime.now().strftime("%H:%M:%S")
    colour = (BOLD + RED) if score >= 10 else YELLOW
    bar = "═" * 60

    print(f"\n{colour}{bar}")
    print(f"  🚨  RANSOMWARE ALERT  [{ts}]")
    print(f"  {message}")
    if score:
        print(f"  Threat Score: {score}")
    print(f"{bar}{RESET}\n")

    if ALERT_SOUND:
        _beep()

    _desktop_notify(message, score)


# ── helpers ──────────────────────────────────────────────────────────────────

def _beep():
    """Cross-platform terminal beep."""
    try:
        if sys.platform == "win32":
            import winsound
            winsound.Beep(1000, 500)
        else:
            sys.stdout.write("\a")
            sys.stdout.flush()
    except Exception:
        pass


def _desktop_notify(message: str, score: int):
    """Desktop pop-up via plyer (optional — silently skipped if not installed)."""
    try:
        from plyer import notification
        notification.notify(
            title="🚨 Ransomware Detected!" if score >= 10 else "⚠️ Ransomware Warning",
            message=message[:256],
            app_name="RansomwareDetector",
            timeout=8,
        )
    except ImportError:
        pass   # plyer not installed — no desktop notification
    except Exception:
        pass
