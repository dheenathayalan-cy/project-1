"""
entropy.py — Shannon entropy calculator.

Ransomware encrypts files, making their byte distribution nearly uniform.
A truly random (fully encrypted) file has Shannon entropy ≈ 8.0 bits/byte.
Legitimate plaintext files typically score < 6.0.

Usage:
    from entropy import calculate_entropy
    score = calculate_entropy("/path/to/file.txt")   # returns float 0.0–8.0
"""

import math
import os
from collections import Counter

# Only read up to this many bytes for speed (enough for a reliable estimate).
SAMPLE_SIZE = 65_536   # 64 KB


def calculate_entropy(filepath: str, sample_size: int = SAMPLE_SIZE) -> float:
    """
    Return Shannon entropy (bits per byte) of *filepath*.
    Reads up to *sample_size* bytes from the file.
    Returns 0.0 if the file cannot be read or is empty.
    """
    try:
        size = os.path.getsize(filepath)
        if size == 0:
            return 0.0

        with open(filepath, "rb") as f:
            data = f.read(sample_size)

        if not data:
            return 0.0

        counts = Counter(data)
        total = len(data)
        entropy = -sum(
            (c / total) * math.log2(c / total)
            for c in counts.values()
        )
        return entropy

    except (OSError, PermissionError):
        return 0.0


def is_high_entropy(filepath: str, threshold: float = 7.5) -> bool:
    """Return True if the file's entropy exceeds *threshold*."""
    return calculate_entropy(filepath) >= threshold


# ── Quick self-test ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys, os

    if len(sys.argv) < 2:
        print("Usage: python entropy.py <file>")
        sys.exit(1)

    path = sys.argv[1]
    score = calculate_entropy(path)
    flag = "🔴 HIGH (possible encryption)" if score >= 7.5 else "🟢 Normal"
    print(f"File   : {path}")
    print(f"Size   : {os.path.getsize(path):,} bytes")
    print(f"Entropy: {score:.4f} bits/byte  →  {flag}")
