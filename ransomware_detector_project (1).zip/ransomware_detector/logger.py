"""
logger.py — Centralised logging setup.
Outputs to both console (coloured) and a rotating log file.
"""

import logging
import sys
from logging.handlers import RotatingFileHandler

# ─── ANSI colour codes for console output ────────────────────────────────────
RESET   = "\033[0m"
RED     = "\033[91m"
YELLOW  = "\033[93m"
GREEN   = "\033[92m"
CYAN    = "\033[96m"
BOLD    = "\033[1m"

LEVEL_COLOURS = {
    "DEBUG"    : CYAN,
    "INFO"     : GREEN,
    "WARNING"  : YELLOW,
    "ERROR"    : RED,
    "CRITICAL" : BOLD + RED,
}


class ColouredFormatter(logging.Formatter):
    def format(self, record):
        colour = LEVEL_COLOURS.get(record.levelname, RESET)
        record.levelname = f"{colour}{record.levelname:<8}{RESET}"
        return super().format(record)


def setup_logger(log_file: str, max_bytes: int = 5_000_000, backup_count: int = 3):
    logger = logging.getLogger("RansomwareDetector")
    logger.setLevel(logging.DEBUG)

    if logger.handlers:          # avoid duplicate handlers on re-import
        return logger

    fmt = "%(asctime)s  %(levelname)s  %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    # Console handler (coloured)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    ch.setFormatter(ColouredFormatter(fmt=fmt, datefmt=datefmt))

    # File handler (rotating, plain text)
    fh = RotatingFileHandler(log_file, maxBytes=max_bytes,
                              backupCount=backup_count, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(fmt=fmt, datefmt=datefmt))

    logger.addHandler(ch)
    logger.addHandler(fh)
    return logger
