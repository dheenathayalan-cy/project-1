"""
Ransomware Detection and Defense System
"""

import os
import sys
import time
import threading
import psutil
import logging
from datetime import datetime
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# ─── Local modules ────────────────────────────────────────────────────────────
from config import (
    SUSPICIOUS_PROCESSES, SUSPICIOUS_EXTENSIONS,
    WATCH_DIRECTORY, LOG_FILE, ENTROPY_THRESHOLD,
    MAX_RENAMES_PER_MINUTE, ALERT_SOUND
)
from logger import setup_logger
from entropy import calculate_entropy
from network_isolation import isolate_network, restore_network
from alerts import send_alert

# ─── Logging setup ────────────────────────────────────────────────────────────
logger = setup_logger(LOG_FILE)


# ══════════════════════════════════════════════════════════════════════════════
# FILE SYSTEM MONITOR
# ══════════════════════════════════════════════════════════════════════════════

class RansomwareFileHandler(FileSystemEventHandler):
    """
    Monitors the file system for ransomware-like behaviour:
      • Suspicious file extensions (.locked, .encrypted, .crypto …)
      • High-entropy writes (encrypted data looks random)
      • Mass file renaming in a short time window
    """

    def __init__(self):
        super().__init__()
        self.rename_timestamps = []      # track recent rename events
        self.threat_score = 0           # cumulative suspicion score
        self.lock = threading.Lock()

    # ── helpers ───────────────────────────────────────────────────────────────

    def _record_rename(self):
        now = time.time()
        with self.lock:
            self.rename_timestamps = [t for t in self.rename_timestamps
                                      if now - t < 60]
            self.rename_timestamps.append(now)
            count = len(self.rename_timestamps)
        return count

    def _add_threat(self, score, reason):
        with self.lock:
            self.threat_score += score
        logger.warning(f"[THREAT +{score}] {reason}  (total={self.threat_score})")
        send_alert(f"⚠️  {reason}", score)
        if self.threat_score >= 10:
            self._trigger_defense("Threat score reached critical level")

    def _trigger_defense(self, reason):
        logger.critical(f"🚨 DEFENSE TRIGGERED — {reason}")
        send_alert(f"🚨 DEFENSE ACTIVATED: {reason}", 100)
        isolate_network()
        # reset score after action so we don't spam
        with self.lock:
            self.threat_score = 0

    # ── event handlers ────────────────────────────────────────────────────────

    def on_created(self, event):
        if event.is_directory:
            return
        path = event.src_path
        ext = Path(path).suffix.lower()
        if ext in SUSPICIOUS_EXTENSIONS:
            self._add_threat(3, f"Suspicious file created: {path}")

    def on_modified(self, event):
        if event.is_directory:
            return
        path = event.src_path
        if not os.path.isfile(path):
            return
        # entropy check
        try:
            ent = calculate_entropy(path)
            if ent >= ENTROPY_THRESHOLD:
                self._add_threat(2,
                    f"High-entropy write detected ({ent:.2f} bits): {path}")
        except Exception:
            pass

    def on_moved(self, event):
        """Rename = on_moved in watchdog."""
        if event.is_directory:
            return
        dest_ext = Path(event.dest_path).suffix.lower()
        if dest_ext in SUSPICIOUS_EXTENSIONS:
            self._add_threat(3,
                f"File renamed to suspicious extension: {event.dest_path}")

        count = self._record_rename()
        if count >= MAX_RENAMES_PER_MINUTE:
            self._add_threat(4,
                f"Mass rename detected: {count} renames in last 60 s")

    def on_deleted(self, event):
        if event.is_directory:
            return
        # Shadow copy / backup deletion is a hallmark of ransomware
        name = os.path.basename(event.src_path).lower()
        if any(kw in name for kw in ("shadow", "backup", "vss", ".bak")):
            self._add_threat(5,
                f"Backup/shadow file deleted: {event.src_path}")


# ══════════════════════════════════════════════════════════════════════════════
# PROCESS MONITOR
# ══════════════════════════════════════════════════════════════════════════════

class ProcessMonitor:
    """
    Scans running processes every few seconds looking for known
    ransomware process names and kills them immediately.
    """

    def __init__(self, interval=3):
        self.interval = interval
        self._stop_event = threading.Event()

    def start(self):
        t = threading.Thread(target=self._run, daemon=True, name="ProcessMonitor")
        t.start()
        logger.info("Process monitor started.")

    def stop(self):
        self._stop_event.set()

    def _run(self):
        while not self._stop_event.is_set():
            self._scan()
            time.sleep(self.interval)

    def _scan(self):
        for proc in psutil.process_iter(attrs=["pid", "name", "exe", "cmdline"]):
            try:
                name = (proc.info["name"] or "").lower()
                if name in SUSPICIOUS_PROCESSES:
                    self._handle_suspicious(proc, name)
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess):
                pass

    def _handle_suspicious(self, proc, name):
        pid = proc.pid
        msg = f"🚨 Ransomware process detected: {name} (PID {pid})"
        logger.critical(msg)
        send_alert(msg, 100)
        try:
            proc.terminate()
            proc.wait(timeout=3)
            logger.info(f"✅ Terminated: {name} (PID {pid})")
        except psutil.NoSuchProcess:
            logger.info(f"Process {name} already gone.")
        except Exception as e:
            logger.error(f"Could not terminate {name}: {e}")
            try:
                proc.kill()
            except Exception:
                pass
        isolate_network()


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def print_banner():
    print("""
╔══════════════════════════════════════════════════════════╗
║   RANSOMWARE DETECTION AND DEFENSE SYSTEM                ║
╠══════════════════════════════════════════════════════════╣
║  [1] File system monitor  (watchdog + entropy analysis)  ║
║  [2] Process monitor      (known ransomware signatures)  ║
║  [3] Network isolation    (auto-triggered on detection)  ║
╚══════════════════════════════════════════════════════════╝
""")


def main():
    print_banner()

    watch_dir = WATCH_DIRECTORY
    if not os.path.isdir(watch_dir):
        os.makedirs(watch_dir, exist_ok=True)
        logger.info(f"Created watch directory: {watch_dir}")

    logger.info(f"Watching directory : {watch_dir}")
    logger.info(f"Log file           : {LOG_FILE}")

    # ── File system watcher ────────────────────────────────────────────────
    event_handler = RansomwareFileHandler()
    observer = Observer()
    observer.schedule(event_handler, path=watch_dir, recursive=True)
    observer.start()
    logger.info("File system observer started.")

    # ── Process monitor ────────────────────────────────────────────────────
    proc_monitor = ProcessMonitor(interval=3)
    proc_monitor.start()

    print(f"\n✅ System active. Monitoring '{watch_dir}' …")
    print("   Press Ctrl+C to stop.\n")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n\nStopping …")
        observer.stop()
        proc_monitor.stop()

    observer.join()
    logger.info("Ransomware detector stopped.")
    print("Goodbye.")


if __name__ == "__main__":
    main()
