"""
simulate_attack.py — Safe ransomware behaviour simulator.

Mimics the file-system patterns of real ransomware WITHOUT any actual
encryption or harmful activity.  Use this to test the detector.

What it does
────────────
  1. Creates normal "victim" files in the watch directory.
  2. Renames them to ransomware extensions (.locked, .encrypted …).
  3. Overwrites them with high-entropy (random) bytes.
  4. Creates a fake ransom note (README_DECRYPT.txt).
  5. Attempts to delete a fake "shadow" backup file.

Run AFTER starting ransomware_detector.py in another terminal:
    python simulate_attack.py
"""

import os
import sys
import time
import random
import string
from pathlib import Path

# ── make sure we can import config ───────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).parent))
from config import WATCH_DIRECTORY


RANSOM_NOTE = """\
!!!  YOUR FILES HAVE BEEN ENCRYPTED  !!!
================================================
All your important files are encrypted.
To decrypt your files send 0.5 BTC to:
  1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf (FAKE ADDRESS - SIMULATION ONLY)

Contact: decryption@nowhere.invalid
Your unique ID: {uid}

** THIS IS A SIMULATION — NO REAL ENCRYPTION OCCURRED **
"""

VICTIM_FILES = [
    ("report.docx",     b"This is my important work report. Confidential!"),
    ("accounts.xlsx",   b"Jan,Feb,Mar\n1000,2000,3000\n"),
    ("photo.jpg",       bytes(range(256)) * 8),   # fake binary
    ("presentation.pptx", b"PK fake pptx content here"),
    ("notes.txt",       b"My private notes. Do not share."),
    ("backup.bak",      b"BACKUP DATA 2025-07-01"),
    ("shadow_copy.bak", b"SHADOW BACKUP DATA"),
]

ENCRYPTED_EXT = [
    ".locked", ".encrypted", ".crypto",
    ".wncry", ".cerber", ".locky",
]


def _random_uid(length=16):
    return "".join(random.choices(string.ascii_uppercase + string.digits, k=length))


def _high_entropy_bytes(size=1024):
    """Return random bytes (simulates encrypted data, entropy ≈ 8.0)."""
    return bytes(random.getrandbits(8) for _ in range(size))


def run_simulation(watch_dir: str, delay: float = 0.4):
    print("=" * 60)
    print("  RANSOMWARE BEHAVIOUR SIMULATOR  (safe — no real damage)")
    print("=" * 60)
    print(f"  Target directory : {watch_dir}")
    print(f"  Inter-step delay : {delay}s")
    print("=" * 60)
    print()

    watch_path = Path(watch_dir)
    watch_path.mkdir(parents=True, exist_ok=True)

    # ── Step 1: Create victim files ───────────────────────────────────────
    print("[1/5] Creating victim files …")
    for fname, content in VICTIM_FILES:
        p = watch_path / fname
        p.write_bytes(content)
        print(f"      Created : {fname}")
    time.sleep(delay)

    # ── Step 2: Mass-rename to encrypted extensions ───────────────────────
    print("\n[2/5] Renaming files to ransomware extensions (mass rename) …")
    encrypted_files = []
    for fname, _ in VICTIM_FILES:
        original = watch_path / fname
        if not original.exists():
            continue
        ext = random.choice(ENCRYPTED_EXT)
        new_name = watch_path / (fname + ext)
        original.rename(new_name)
        encrypted_files.append(new_name)
        print(f"      {fname}  →  {fname + ext}")
        time.sleep(0.05)    # rapid-fire renames to trip the detector

    time.sleep(delay)

    # ── Step 3: Overwrite with high-entropy bytes ─────────────────────────
    print("\n[3/5] Overwriting files with high-entropy (encrypted) data …")
    for p in encrypted_files:
        p.write_bytes(_high_entropy_bytes(4096))
        print(f"      Overwritten: {p.name}  (entropy ≈ 8.0)")
        time.sleep(0.05)

    time.sleep(delay)

    # ── Step 4: Drop ransom note ──────────────────────────────────────────
    print("\n[4/5] Dropping ransom note …")
    note_path = watch_path / "README_DECRYPT.txt"
    note_path.write_text(RANSOM_NOTE.format(uid=_random_uid()))
    print(f"      Created : {note_path.name}")
    time.sleep(delay)

    # ── Step 5: Delete shadow / backup files ──────────────────────────────
    print("\n[5/5] Deleting backup/shadow files …")
    for p in list(watch_path.glob("*.bak")) + list(watch_path.glob("*shadow*")):
        try:
            p.unlink()
            print(f"      Deleted : {p.name}")
        except FileNotFoundError:
            pass
    time.sleep(delay)

    print("\n" + "=" * 60)
    print("  Simulation complete.")
    print("  The detector should have raised multiple alerts above.")
    print("=" * 60)


if __name__ == "__main__":
    run_simulation(WATCH_DIRECTORY)
