# Ransomware Detection and Defense System 🛡️

---

## Overview

A lightweight, real-time Python system that monitors for ransomware activity using three detection layers:

| Layer | Module | What it catches |
|---|---|---|
| File System Monitor | `watchdog` | Suspicious extensions, mass renames, entropy spikes, backup deletion |
| Process Monitor | `psutil` | Known ransomware process names |
| Network Isolation | `netsh` / `iptables` / `pfctl` | Auto-blocks network on confirmed threat |

---

## Project Structure

```
ransomware_detector/
├── ransomware_detector.py   ← Main entry point
├── config.py                ← All settings (edit this)
├── logger.py                ← Coloured console + rotating file log
├── entropy.py               ← Shannon entropy calculator
├── network_isolation.py     ← Cross-platform firewall control
├── alerts.py                ← Console + sound + desktop notifications
├── simulate_attack.py       ← Safe attack simulator for testing
├── requirements.txt
└── README.md
```

---

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure the watch directory
Open **`config.py`** and set `WATCH_DIRECTORY` to the folder you want to protect:
```python
WATCH_DIRECTORY = r"C:\Users\YourName\Documents"   # Windows
WATCH_DIRECTORY = "/home/yourname/Documents"        # Linux / macOS
```

### 3. Start the detector
```bash
python ransomware_detector.py
```

### 4. Test it (in a second terminal)
```bash
python simulate_attack.py
```

Watch the first terminal — you should see alerts fire within seconds.

---

## How Detection Works

### 🔍 File System Monitor (`RansomwareFileHandler`)
Built on the `watchdog` library. Runs continuously in a background thread.

- **Extension check** — any file created or renamed to a known ransomware extension (`.locked`, `.encrypted`, `.wncry`, etc.) adds **+3** to the threat score.
- **Shannon entropy** — after every file write, the system reads up to 64 KB and computes entropy. Scores ≥ 7.5 bits/byte (threshold configurable) add **+2** (encrypted data looks statistically random).
- **Mass rename** — more than `MAX_RENAMES_PER_MINUTE` renames in 60 seconds adds **+4** (ransomware renames every file it encrypts).
- **Backup deletion** — deleting files matching `shadow*`, `*.bak`, `backup*` adds **+5** (ransomware deletes shadow copies to prevent recovery).

When **threat score ≥ 10**, network isolation is triggered automatically.

### ⚙️ Process Monitor (`ProcessMonitor`)
Polls `psutil.process_iter()` every 3 seconds. If a process name matches the `SUSPICIOUS_PROCESSES` list (wannacry.exe, locky.exe, ryuk.exe, etc.) it is **immediately terminated** and network isolation is triggered.

### 🌐 Network Isolation (`network_isolation.py`)
Blocks all inbound and outbound traffic to stop lateral movement and C&C communication.

| OS | Command |
|---|---|
| Windows | `netsh advfirewall set allprofiles firewallpolicy blockinbound,blockoutbound` |
| Linux | `iptables -P INPUT DROP && iptables -P OUTPUT DROP` |
| macOS | `pfctl -ef -` with `block all` ruleset |

> **Safe demo mode:** Set `ISOLATION_MODE = "simulate"` in `config.py` to log actions without touching real firewall rules.

---

## Configuration Reference (`config.py`)

| Setting | Default | Description |
|---|---|---|
| `WATCH_DIRECTORY` | `~/Documents/ransomware_watch` | Folder to monitor |
| `LOG_FILE` | `ransomware_log.txt` | Log file path |
| `SUSPICIOUS_PROCESSES` | 20 known names | Set of process names to kill |
| `SUSPICIOUS_EXTENSIONS` | 40+ extensions | File extensions that trigger alerts |
| `ENTROPY_THRESHOLD` | `7.5` | Bits/byte threshold for high-entropy detection |
| `MAX_RENAMES_PER_MINUTE` | `10` | Rename rate that triggers mass-rename alert |
| `ALERT_SOUND` | `True` | Play a beep on detection |
| `ISOLATION_MODE` | `"simulate"` | `"simulate"` or `"enforce"` |

---

## Entropy Tool (standalone)
```bash
python entropy.py myfile.docx
```
Output:
```
File   : myfile.docx
Size   : 14,235 bytes
Entropy: 7.91 bits/byte  →  🔴 HIGH (possible encryption)
```

---

## Adding Your Own Signatures

**New ransomware process name:**
```python
# config.py
SUSPICIOUS_PROCESSES.add("newransomware.exe")
```

**New extension:**
```python
SUSPICIOUS_EXTENSIONS.add(".newext")
```

---

## Running as Administrator (for real isolation)
Network isolation requires elevated privileges.

**Windows** — right-click Command Prompt → *Run as administrator*  
**Linux / macOS** — prefix with `sudo`

Then set `ISOLATION_MODE = "enforce"` in `config.py`.

---

## Restoring the Network (after isolation)
```python
from network_isolation import restore_network
restore_network()
```
Or run `python -c "from network_isolation import restore_network; restore_network()"`.

---

## Technologies Used

| Library | Purpose |
|---|---|
| `watchdog` | Real-time file system event monitoring |
| `psutil` | Cross-platform process and system monitoring |
| `plyer` | Optional desktop notifications |
| `math`, `collections` | Shannon entropy calculation |
| `subprocess` | Firewall command execution |
| `threading` | Concurrent monitor threads |
| `logging` | Rotating log files |
