"""
config.py — All tunable settings for the Ransomware Detector
Edit this file to customise behaviour without touching the core logic.
"""

import os
from pathlib import Path

# ─── Directory to monitor ─────────────────────────────────────────────────────
# Change this to any folder you want to protect, e.g.:
#   Windows : r"C:\Users\YourName\Documents"
#   Linux   : "/home/yourname/Documents"
WATCH_DIRECTORY = str(Path.home() / "Documents" / "ransomware_watch")

# ─── Log file path ────────────────────────────────────────────────────────────
LOG_FILE = str(Path(__file__).parent / "ransomware_log.txt")

# ─── Known ransomware process names (lowercase) ───────────────────────────────
# Add more as new strains are discovered.
SUSPICIOUS_PROCESSES = {
    # Classic / well-known ransomware
    "wannacry.exe",
    "wncry.exe",
    "notpetya.exe",
    "petya.exe",
    "locky.exe",
    "cryptolocker.exe",
    "ryuk.exe",
    "sodinokibi.exe",
    "revil.exe",
    "darkside.exe",
    "blackcat.exe",
    "lockbit.exe",
    "conti.exe",
    "maze.exe",
    "ransomware.exe",
    # Generic names sometimes used by test samples
    "encrypt.exe",
    "fileencryptor.exe",
    "cryptor.exe",
}

# ─── File extensions added by ransomware after encryption ────────────────────
SUSPICIOUS_EXTENSIONS = {
    ".locked",
    ".encrypted",
    ".encrypt",
    ".crypto",
    ".crypt",
    ".crypted",
    ".enc",
    ".locky",
    ".wnry",
    ".wncry",
    ".wcry",
    ".cerber",
    ".cerber2",
    ".cerber3",
    ".ccc",
    ".vvv",
    ".exx",
    ".ezz",
    ".abc",
    ".xyz",
    ".micro",
    ".zepto",
    ".thor",
    ".aesir",
    ".osiris",
    ".odin",
    ".shit",          # Locky variant
    ".pay2decrypt",
    ".ransom",
    ".r5a",
    ".kraken",
    ".darkness",
    ".nochance",
    ".oshit",
    ".unavailable",
    ".paymst",
    ".gefickt",
    ".hacked",
    ".korea",
    ".los_pollos",
}

# ─── Shannon entropy threshold (bits per byte, max = 8.0) ────────────────────
# Files encrypted by ransomware have very high entropy (≥ 7.5).
# Legitimate compressed files (ZIP, MP4) can also be ~7.5–8.0,
# so this is used as a signal alongside other indicators.
ENTROPY_THRESHOLD = 7.5

# ─── Mass-rename detection ────────────────────────────────────────────────────
# Trigger alert if more than this many renames happen within 60 seconds.
MAX_RENAMES_PER_MINUTE = 10

# ─── Alert sound ─────────────────────────────────────────────────────────────
# Set to True to play a system beep on detection (works on Linux/macOS/Win).
ALERT_SOUND = True

# ─── Network isolation mode ───────────────────────────────────────────────────
# "simulate" → just log, do NOT actually change firewall rules (safe for demo)
# "enforce"  → apply real firewall rules (requires admin/root privileges)
ISOLATION_MODE = "simulate"   # change to "enforce" when running as admin/root
